from django.shortcuts import render, HttpResponseRedirect
from .forms import PatientRecord
from .models import User
# Create your views here.

# Add Records using this function
def add_show(request):
    if request.method == 'POST':
        fm = PatientRecord(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            ag = fm.cleaned_data['age']
            gn = fm.cleaned_data['gender']
            sp = fm.cleaned_data['symptoms']
            pre = fm.cleaned_data['prescription']
            da = fm.cleaned_data['date_of_visit']
            reg = User(name=nm,age=ag,gender=gn,symptoms=sp,prescription=pre,date_of_visit=da)
            reg.save()
            fm = PatientRecord()
    else:
        fm = PatientRecord()
    patie = User.objects.all()
    return render(request, 'enroll/addandshow.html', {'form':fm, 'pat':patie})

# Update/Edit Record using this function
def update_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        fm = PatientRecord(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = User.objects.get(pk=id)
        fm = PatientRecord(instance=pi)
    return render(request, 'enroll/updatepatient.html', {'form':fm})

# Delete Record using this fuction
def delete_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')
    

