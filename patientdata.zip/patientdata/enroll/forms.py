from django.core import validators
from django import forms
from django.forms import widgets
from .models import User

class DateInput(forms.DateInput):
    input_type = 'date'

class PatientRecord(forms.ModelForm):
    class Meta:
        
        model = User
        fields = ['name', 'age', 'gender','symptoms','prescription', 'date_of_visit']
       
        widgets = {'name':forms.TextInput(attrs={'class':'form-control'}),
            'age':forms.NumberInput(attrs={'class':'form-control'}),
            'gender':forms.RadioSelect(),
            'symptoms':forms.TextInput(attrs={'class':'form-control'}),
            'prescription':forms.TextInput(attrs={'class':'form-control'}),
            'date_of_visit':DateInput(),
            }