from django.db import models

# Create your models here.
GENDERS = [(1,'Male'),(2,'Female')]

class User(models.Model):
    
    name = models.CharField(max_length=100)
    age = models.CharField(max_length=100)
    gender = models.IntegerField(choices=GENDERS, default=1)
    symptoms = models.CharField(max_length=100)
    prescription = models.CharField(max_length=100)
    date_of_visit = models.DateTimeField()
    

    